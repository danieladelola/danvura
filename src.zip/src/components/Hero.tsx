import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center pt-20 md:pt-0">
      <div className="container-wide mx-auto px-6 md:px-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Content */}
          <div>
            <p className="text-primary font-medium mb-4 animate-fade-up">
              Digital Marketing & Brand Building
            </p>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-foreground leading-tight mb-6 animate-fade-up animation-delay-100">
              I'm Daniel Adelola
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed mb-8 animate-fade-up animation-delay-200">
              Helping businesses grow online through marketing and branding that works.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up animation-delay-300">
              <Button variant="hero" size="xl" asChild>
                <a href="#contact">
                  Work With Me
                  <ArrowRight className="ml-2" size={20} />
                </a>
              </Button>
              <Button variant="outline-dark" size="xl" asChild>
                <a href="#work">View My Work</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
